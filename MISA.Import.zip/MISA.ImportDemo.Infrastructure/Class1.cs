﻿using System;

namespace MISA.ImportDemo.Infrastructure
{
    public class Class1
    {
    }
}
