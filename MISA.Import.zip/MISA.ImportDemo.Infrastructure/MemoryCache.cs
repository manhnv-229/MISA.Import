﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.ImportDemo.Infrastructure
{
    public static class MemoryCache
    {
        public static IMemoryCache _importMemoryCache;
        
    }
}
